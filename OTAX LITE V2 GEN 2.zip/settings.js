
const settings = {
  OWNER_URL: "http://t.me/Zono991", //ganti Otapengenkawin dengan username tele lu
};
//ganti bagian dalam '...' saja
module.exports = settings;