module.exports = {
  BOT_TOKEN: "7234270007:AAFkbmWTxUQKVkSHFOjk1tnoRn6rFkDhtBk",//bot tokenlu
  OWNER_ID: ["7584587633"],//id lu
  API_HASH: "01affc9ea4e8a587d39b640ac19a5cf9",
  API_ID: 21290664,//ganti 0 dan langsung isi angka nya saja ex: 12323232
  //Baca Readme.txt agar kalian faham cara menggunakan ban CH ( Login Dengan Akun Telegram Premium Lebih Work Dan Cepat Terban ) terima kasih
  // Thanks To Ota And Dimz
};
//BY OTAX